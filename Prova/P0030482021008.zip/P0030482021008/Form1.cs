﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030482021008
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] vendas = new double[8, 4];
            double[] totalMes = new double[8];
            double totalGeral = 0;
            string valor;

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    valor = Interaction.InputBox("Valor recebido na semana " + (j + 1) + " do mês " + (i + 1) + ":", "Entrada de dados");
                    if (valor == "")
                    {
                        MessageBox.Show("Preencha o campo!");
                        j--;
                    }
                    else if (double.TryParse(valor, out vendas[i, j]))
                    {
                        double.TryParse(valor, out vendas[i, j]);
                    }
                    else
                    {
                        MessageBox.Show("Valor inválido, digite apenas números!");
                        j--;
                    }
                }
            }

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    totalMes[i] = totalMes[i] + vendas[i, j];
                }
                totalGeral = totalGeral + totalMes[i];
            }

            lboxResultados.Items.Add(" >>>>> Valores das vendas <<<<< ");
            lboxResultados.Items.Add("---------------------------------------------------------------");

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    lboxResultados.Items.Add("Total do mês " + (i + 1) + " semana " + (j + 1) + "=> R$" + vendas[i, j].ToString("N2"));
                }
                lboxResultados.Items.Add("••• Total do mês => R$" + totalMes[i].ToString("N2") + " •••");
                lboxResultados.Items.Add("---------------------------------------------------------------");
            }
            lboxResultados.Items.Add(" >>> Total geral => R$" + totalGeral.ToString("N2") + " <<<");
        
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lboxResultados.Items.Clear();
        }
    }
}
