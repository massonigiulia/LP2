﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PVacina0030482021008
{
    public partial class frmVacina : Form
    {
        private BindingSource bnVacina = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsVacina = new DataSet();

        private BindingSource bnCidade = new BindingSource();
        private DataSet dsCidade = new DataSet();

        private BindingSource bnEnfermeiro = new BindingSource();
        private DataSet dsEnfermeiro = new DataSet();

        public frmVacina()
        {
            InitializeComponent();
        }

        private void frmVacina_Load(object sender, EventArgs e)
        {
            try
            {
                Vacina RegVac = new Vacina();
                dsVacina.Tables.Add(RegVac.Listar());
                bnVacina.DataSource = dsVacina.Tables["Vacina"];
                dgvVacina.DataSource = bnVacina;
                bndVacina.BindingSource = bnVacina;
                

                txtIdVacina.DataBindings.Add("Text", bnVacina, "id_vacina");
                txtVacina.DataBindings.Add("Text", bnVacina, "nome_vacina");
                txtEndereco.DataBindings.Add("Text", bnVacina, "end_vacina");
                dtDataNasc.DataBindings.Add("Text", bnVacina, "datanasc_vacina");
                dtVacina.DataBindings.Add("Text", bnVacina, "data_vacina");
                mskCPF.DataBindings.Add("Text", bnVacina, "cpf_vacina");
                mskRG.DataBindings.Add("Text", bnVacina, "rg_vacina");
                cmbComorbidade.DataBindings.Add("SelectedItem", bnVacina, "comorbidade_vacina");
                cmbPrioritario.DataBindings.Add("SelectedItem", bnVacina, "grupopriori_vacina");
                cmbTipoVacina.DataBindings.Add("SelectedItem", bnVacina, "tipo_vacina");
                //txtCidade.DataBindings.Add("Text", bnVacina, "cidade_id_cidade");
                //txtEnfermeiro.DataBindings.Add("Text", bnVacina, "enfermeiro_id_enfermeiro");
                // AJUSTAR DROPDOWNSTYLE PARA DropDownList PARA NAO DEIXAR INCLUIR

                Cidade cid = new Cidade();
                dsCidade.Tables.Add(cid.Listar());
                cmbCidade.DataSource = dsCidade.Tables["Cidade"];

                Enfermeiro enf = new Enfermeiro();
                dsEnfermeiro.Tables.Add(enf.Listar());
                cmbEnfermeiro.DataSource = dsEnfermeiro.Tables["Enfermeiro"];

                cmbCidade.DataBindings.Add("SelectedItem", bnVacina, "cidade_id_cidade");
                cmbEnfermeiro.DataBindings.Add("SelectedItem", bnVacina, "enfermeiro_id_enfermeiro");

                cmbCidade.DisplayMember = "nome_cidade";
                cmbCidade.ValueMember = "id_cidade";

                cmbEnfermeiro.DisplayMember = "nome_enfermeiro";
                cmbEnfermeiro.ValueMember = "id_enfermeiro";

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (tbVacina.SelectedIndex == 0)
            {
                tbVacina.SelectTab(1);
            }
            
            bnVacina.AddNew();
            txtVacina.Enabled = true;
            txtEndereco.Enabled = true;
            dtDataNasc.Enabled = true;
            dtVacina.Enabled = true;
            mskCPF.Enabled = true;
            mskRG.Enabled = true;
            cmbCidade.Enabled = true;
            cmbEnfermeiro.Enabled = true;
            cmbComorbidade.Enabled = true;
            cmbPrioritario.Enabled = true;
            cmbTipoVacina.Enabled = true;

            cmbCidade.SelectedIndex = 0;
            cmbEnfermeiro.SelectedIndex = 0;
            cmbComorbidade.SelectedIndex = 0;
            cmbPrioritario.SelectedIndex = 0;
            cmbTipoVacina.SelectedIndex = 0;

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {

            ///Validando os dados:
            if (txtVacina.Text == "")
                MessageBox.Show("Nome vazio");
            else if (txtEndereco.Text == "")
                MessageBox.Show("Endereço vazio");
            else if (mskCPF.Text == "")
                MessageBox.Show("CPF vazio");
            else if (mskRG.Text == "")
                MessageBox.Show("RG vazio");
    
            else
            {
                Vacina RegVac = new Vacina();

                RegVac.NomeVacina = txtVacina.Text;
                RegVac.EndVacina = txtEndereco.Text;
                RegVac.DataNascVacina = Convert.ToDateTime(dtDataNasc.Text);
                RegVac.DataVacina = Convert.ToDateTime(dtVacina.Text);
                RegVac.CpfVacina = mskCPF.Text;
                RegVac.RgVacina = mskRG.Text;
                RegVac.GrupoPrioriVacina = Convert.ToChar(cmbPrioritario.SelectedItem.ToString());
                RegVac.TipoVacina = Convert.ToChar(cmbTipoVacina.SelectedItem.ToString());
                RegVac.ComorbidadeVacina = Convert.ToChar(cmbComorbidade.SelectedItem.ToString());
                RegVac.CidadeIdVacina = Convert.ToInt32(cmbCidade.SelectedValue.ToString());
                RegVac.EnfermeiroIdEnfermeiro = Convert.ToInt32(cmbEnfermeiro.SelectedValue.ToString());
                if (bInclusao)
                {
                    if (RegVac.Salvar() > 0)
                    {
                        MessageBox.Show("Vacina adicionada com sucesso!");

                        bInclusao = false;

                        txtVacina.Enabled = false;
                        txtEndereco.Enabled = false;
                        dtDataNasc.Enabled = false;
                        dtVacina.Enabled = false;
                        mskCPF.Enabled = false;
                        mskRG.Enabled = false;
                        cmbCidade.Enabled = false;
                        cmbEnfermeiro.Enabled = false;
                        cmbComorbidade.Enabled = false;
                        cmbPrioritario.Enabled = false;
                        cmbTipoVacina.Enabled = false;

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        // recarrega o grid
                        dsVacina.Tables.Clear();
                        dsVacina.Tables.Add(RegVac.Listar());
                        bnVacina.DataSource = dsVacina.Tables["VACINA"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar vacina!");
                    }
                }
                else
                {
                    RegVac.IdVacina = Convert.ToInt32(txtIdVacina.Text);

                    if (RegVac.Alterar() > 0)
                    {
                        MessageBox.Show("Vacina alterada com sucesso!");

                        txtVacina.Enabled = false;
                        txtEndereco.Enabled = false;
                        dtDataNasc.Enabled = false;
                        dtVacina.Enabled = false;
                        mskCPF.Enabled = false;
                        mskRG.Enabled = false;
                        cmbCidade.Enabled = false;
                        cmbEnfermeiro.Enabled = false;
                        cmbComorbidade.Enabled = false;
                        cmbPrioritario.Enabled = false;
                        cmbTipoVacina.Enabled = false;

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        // recarrega o grid
                        dsVacina.Tables.Clear();
                        dsVacina.Tables.Add(RegVac.Listar());
                        bnVacina.DataSource = dsVacina.Tables["VACINA"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar vacina!");
                    }
                }
            }


        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbVacina.SelectedIndex == 0)
            {
                tbVacina.SelectTab(1);
            }

            txtVacina.Enabled = true;
            txtEndereco.Enabled = true;
            dtDataNasc.Enabled = true;
            dtVacina.Enabled = true;
            mskCPF.Enabled = true;
            mskRG.Enabled = true;
            cmbCidade.Enabled = true;
            cmbEnfermeiro.Enabled = true;
            cmbComorbidade.SelectedIndex = 0;
            cmbPrioritario.SelectedIndex = 0;
            cmbTipoVacina.SelectedIndex = 0;

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = false;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnVacina.CancelEdit();

            txtVacina.Enabled = false;
            txtEndereco.Enabled = false;
            dtDataNasc.Enabled = false;
            dtVacina.Enabled = false;
            mskCPF.Enabled = false;
            mskRG.Enabled = false;
            cmbCidade.Enabled = false;
            cmbEnfermeiro.Enabled = false;
            cmbComorbidade.Enabled = false;
            cmbPrioritario.Enabled = false;
            cmbTipoVacina.Enabled = false;

            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovo.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tbVacina.SelectedIndex == 0)
            {
                tbVacina.SelectTab(1);
            }
            Vacina RegVac = new Vacina();

            RegVac.IdVacina = Convert.ToInt32(txtIdVacina.Text);

            if (MessageBox.Show("Confirma exclusão?", "Yes or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                if (RegVac.Excluir() == 0)
                    MessageBox.Show("Erro ao excluir vacina");
                else
                {
                    MessageBox.Show("Vacina excluida com sucesso");

                    // recarrega o grid
                    dsVacina.Tables.Clear();
                    dsVacina.Tables.Add(RegVac.Listar());
                    bnVacina.DataSource = dsVacina.Tables["vacina"];
                }
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
